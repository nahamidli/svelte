<script>
	import Button from '$lib/Button.svelte';
</script>

<svelte:head>
   <title>SM Vessel Client</title>
</svelte:head>

<h1>Welcome to SvelteKit</h1>
<p>Visit <a href="https://kit.svelte.dev">kit.svelte.dev</a> to read the documentation</p>

<Button>Hello, I am Vessel Client :) </Button>
