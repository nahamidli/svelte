<script>
	import '../app.css';
	import Nav from '../components/nav.svelte';
</script>

<Nav></Nav>
<slot />
