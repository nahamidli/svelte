<button class="p-2 bg-digital-blue-400"><slot /></button>
